A Pen created at CodePen.io. You can find this one at http://codepen.io/WithAnEs/pen/Fxzei.

 Created for the 404 section for my portfolio site. Wanted something a pretty animated to add interest to this often forgottent page.